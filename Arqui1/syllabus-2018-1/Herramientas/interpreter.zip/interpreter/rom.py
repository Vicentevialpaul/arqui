from .entity import Entity
from .cons import CONS


class Rom(Entity):
    def __init__(self, path, **kwargs):
        super().__init__(**kwargs)
        self.instructions = []
        data = None
        code = False
        ignore_head = False
        ram_addr = 0
        line = 0
        variables = {}
        self.labels = {}
        with open(path, 'r') as file:
            for line in file.readlines():
                line = line.strip()
                if line.find('//') != -1:
                    comment = line[line.index('//'):]
                    if comment.lower().split()[0] == '//prt' and len(line[:line.index('//')]) == 0:
                        line = comment[2:]
                    elif comment.lower() == '//head' \
                            and len(line[:line.index('//')]) == 0 \
                            and 'head' in kwargs \
                            and kwargs['head'] is not None:
                        if not ignore_head:
                            head = kwargs['head']
                            for head_line in head.split("#separator#"):
                                head_line = head_line.strip()
                                if head_line.find('//') != -1:
                                    head_line = head_line[:head_line.index('//')]
                                inst = head_line
                                args = []
                                if head_line.find(' ') != -1:
                                    i = head_line.index(' ')
                                    inst = head_line[:i]
                                    args = get_args(head_line[i:].strip())
                                if data is None and inst.lower() == 'data:':
                                    data = True
                                elif data:
                                    if inst.lower() == 'code:':
                                        data = False
                                        code = True
                                    else:
                                        if inst is not None and len(inst) > 0:
                                            if is_label(inst):
                                                self.labels[inst] = ram_addr
                                            elif is_jump(inst):
                                                self.instructions.append(['{} lit', 'label,{}'.format(args[0])])
                                                self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                            else:
                                                if len(args) == 1:
                                                    self.instructions.append(
                                                        ['mov a, lit', 'number,{}'.format(args[0])])
                                                    variables[inst] = ram_addr
                                                else:
                                                    self.instructions.append(['mov a, lit', 'number,{}'.format(inst)])
                                                self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                            ram_addr += 1
                        ignore_head = not ignore_head
                        line = line[:line.index('//')]
                    else:
                        line = line[:line.index('//')]
                if ignore_head:
                    continue
                if len(line) > 0:
                    inst = line
                    args = []
                    splited = line.split()
                    if len(splited) > 1:
                        inst = splited[0].strip()
                        args = get_args(' '.join(splited[1:]))
                    if data is None and inst.lower() == 'data:':
                        data = True
                    elif data:
                        if inst.lower() == 'code:':
                            data = False
                            code = True
                        else:
                            if inst is not None and len(inst) > 0:
                                if is_label(inst):
                                    self.labels[inst] = ram_addr
                                elif len(args) == 0:
                                    number = inst
                                    if number[-1] == "h":
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(int(number[:-1], 16))])
                                    elif number[-1] == "b":
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(int(number[:-1], 2))])
                                    elif number[-1] == "d":
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(int(number[:-1]))])
                                    else:
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(int(number))])
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                                elif args[0][0] == "\"" and args[0][-1] == "\"":
                                    variables[inst] = ram_addr
                                    for c in args[0][1:-1]:
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(ord(c))])
                                        self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                        ram_addr += 1
                                elif args[0][-1] == "h":
                                    self.instructions.append(['mov a, lit', 'number,{}'.format(int(args[0][:-1], 16))])
                                    variables[inst] = ram_addr
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                                elif args[0][-1] == "b":
                                    self.instructions.append(['mov a, lit', 'number,{}'.format(int(args[0][:-1], 2))])
                                    variables[inst] = ram_addr
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                                elif args[0][-1] == "d":
                                    self.instructions.append(['mov a, lit', 'number,{}'.format(int(args[0][:-1]))])
                                    variables[inst] = ram_addr
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                                elif is_jump(inst):
                                    self.instructions.append(['{} lit', 'label,{}'.format(args[0])])
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                                else:
                                    if len(args) == 1:
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(args[0])])
                                        variables[inst] = ram_addr
                                    else:
                                        self.instructions.append(['mov a, lit', 'number,{}'.format(inst)])
                                    self.instructions.append(['mov (dir), a', 'number,{}'.format(ram_addr)])
                                    ram_addr += 1
                    elif code:
                        old_inst = inst
                        inst = inst.lower()
                        if inst[-1] == ':':
                            self.labels[old_inst[:-1]] = len(self.instructions)
                        else:
                            arg1 = None
                            arg2 = None
                            kind = 'number'
                            l = 0
                            if is_jump(inst):
                                arg1 = 'ins'
                                kind = 'label'
                                l = args[0]
                            else:
                                if len(args) > 0:
                                    if args[0] == 'A' or args[0] == 'B':
                                        arg1 = args[0].lower()
                                    elif args[0] == '(A)' or args[0] == '(B)':
                                        arg1 = args[0].lower()
                                    elif args[0][0] == '(' and args[0][-1] == ')':
                                        arg1 = '(dir)'
                                        l = variables[args[0][1:-1]]
                                    else:
                                        if args[0] in variables:
                                            l = variables[args[0]]
                                        else:
                                            l = args[0]
                                        arg1 = 'lit'
                                if len(args) > 1:
                                    if args[1] == 'A' or args[1] == 'B':
                                        arg2 = args[1].lower()
                                    elif args[1] == '(A)' or args[1] == '(B)':
                                        arg2 = args[1].lower()
                                    elif args[1][0] == '(' and args[1][-1] == ')':
                                        arg2 = '(dir)'
                                        l = variables[args[1][1:-1]]
                                    else:
                                        if args[1] in variables:
                                            l = variables[args[1]]
                                        else:
                                            l = args[1]
                                        arg2 = 'lit'
                            if inst == 'prt':
                                v = None
                                if args[0].lower() == 'a' or args[0].lower() == 'b':
                                    v = 'reg,{}'.format(args[0].lower())
                                elif args[0][0] == '(' and args[0][-1] == ')':
                                    v = 'number,{}'.format(variables[args[0][1:-1]])
                                self.instructions.append(['prt', v])
                            elif is_inst(inst):
                                if arg1:
                                    if arg2:
                                        op = "{} {}, {}".format(inst, arg1, arg2)
                                    else:
                                        op = "{} {}".format(inst, arg1)
                                else:
                                    op = inst
                                if inst == 'pop' or inst == 'ret':
                                    self.instructions.append(['incsp', "number,0"])
                                self.instructions.append([op, "{},{}".format(kind, l)])
        # print(variables)

    def behave(self):
        if self.pc.value >= len(self.instructions):
            CONS.cancelled = True
        else:
            self.opcode.value, value = self.instructions[self.pc.value]
            self.lit.value = self.get_lit(value)

    def get_lit(self, value):
        kind, v = value.split(',')
        if kind == 'label':
            return self.labels[v]
        elif kind == 'number':
            if value[-1] == "h":
                return int(v[:-1], 16)
            elif value[-1] == "b":
                return int(v[:-1], 2)
            elif value[-1] == "d":
                return int(v[:-1])
            else:
                return int(v)
        elif kind == 'reg':
            return v


class EmptyRom(Exception):
    pass


def get_args(s):
    return list(map(lambda x: x.strip(), s.split(',')))


def get_value(s):
    def _get_value():
        v = int(s)
        return v
    return _get_value


def is_jump(inst):
    return inst.lower() in ['jmp', 'jle', 'jeq', 'jne', 'jgt', 'jge', 'jlt', 'jcr', 'call']


def is_label(inst):
    return inst[-1] == ':'


def is_inst(inst):
    return True


if __name__ == '__main__':
    r = Rom('rom.txt')


