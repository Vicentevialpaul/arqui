from .entity import Entity


class Alu(Entity):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def behave(self):
        c = 0
        n = 0
        z = 0
        v = self.data_out.value
        if self.sel.value == 'add':
            v = self.a.value + self.b.value
            c = v >= 2**16
            self.data_out.value = v
        elif self.sel.value == 'sub':
            v = self.a.value - self.b.value
            c = v < 0
            self.data_out.value = self.a.value - self.b.value
        elif self.sel.value == 'shr':
            v = self.a.value >> 1
            c = self.a.value % 2 == 1
            self.data_out.value = v
        elif self.sel.value == 'shl':
            v = self.a.value << 1
            c = v >= 2**16
        elif self.sel.value == 'and':
            v = self.a.value & self.b.value
        elif self.sel.value == 'or':
            v = self.a.value | self.b.value
        elif self.sel.value == 'not':
            v = (~self.a.value) % (2 ** 16)
        elif self.sel.value == 'mul':
            v = self.a.value * self.b.value
        self.data_out.value = v
        self.c.value = c
        self.z.value = v == 0
        self.n.value = v < 0
