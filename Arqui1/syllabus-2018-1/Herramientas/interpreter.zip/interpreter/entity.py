class Entity:

    def __init__(self, in_=None, out=None, extras=None, **kwargs):
        self.in_signals = in_
        self.instances = {}
        self.out_signals = out
        self.extras = extras

    def __getattr__(self, item):
        if self.in_signals is not None and item in self.in_signals:
            return self.in_signals[item]
        elif self.out_signals is not None and item in self.out_signals:
            return self.out_signals[item]
        else:
            return super().__getattribute__(item)

    def behave(self):
        pass
