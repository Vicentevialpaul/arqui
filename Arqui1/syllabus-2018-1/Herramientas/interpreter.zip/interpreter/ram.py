from .entity import Entity


class Ram(Entity):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.data = [0]*(2**16)

    def behave(self):
        if self.clock.value == 1:
            if self.load.value == 1:
                self.data[self.sel.value % (2**16)] = self.data_in.value
        self.data_out.value = self.data[self.sel.value % (2**16)]
