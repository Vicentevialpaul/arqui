class Cons:

    def __init__(self):
        self.cancelled = False


CONS = Cons()