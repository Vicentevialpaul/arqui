import argparse
from interpreter.basys import Basys3
from interpreter.cons import CONS
import tkinter as tk
from tkinter import filedialog


def main():
    root = tk.Tk()
    root.withdraw()

    file_path = filedialog.askopenfilename()

    basys3 = Basys3(file_path, extras={
        'time': 0.1
    })
    while not CONS.cancelled:
        basys3.behave()
        if basys3.clock.value == 1:
            t = 1
        else:
            t = 1
        for _ in range(t):
            basys3.instances['rom'].behave()
            basys3.instances['control_unit'].behave()
            basys3.instances['alu'].behave()
            basys3.instances['reg_a'].behave()
            basys3.instances['reg_b'].behave()
            basys3.instances['ram'].behave()
            basys3.instances['sp'].behave()
            basys3.instances['pc'].behave()
            basys3.instances['mux_a'].behave()
            basys3.instances['mux_b'].behave()
            basys3.instances['reg_c'].behave()
            basys3.instances['reg_z'].behave()
            basys3.instances['reg_n'].behave()
            basys3.instances['mux_s'].behave()
            basys3.instances['mux_data_in'].behave()
            basys3.instances['adder'].behave()
            basys3.instances['mux_pc'].behave()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("Cancelled...")
