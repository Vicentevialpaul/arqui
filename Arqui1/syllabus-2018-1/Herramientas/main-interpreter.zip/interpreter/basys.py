from .adder import Adder
from .alu import Alu
from .control_unit import ControlUnit
from .entity import Entity
from .mux import Mux
from .reg import Reg
from .rom import Rom
from .signal import Signal
from .ram import Ram


class Basys3(Entity):

    def __init__(self, rom_path, extras=None, head=None):
        super().__init__(extras=extras)
        self.clock = Signal(1)

        self.pc_load = Signal()
        self.pc_inc = Signal(1)
        self.pc_dec = Signal()
        self.pc_data_in = Signal()
        self.pc_out = Signal()

        self.lit = Signal()
        self.opcode = Signal()

        self.reg_a_load = Signal()
        self.reg_a_inc = Signal()
        self.reg_a_dec = Signal()
        self.reg_a_out = Signal()

        self.mux_a_sel = Signal('zero')
        self.mux_a_out = Signal()

        self.reg_b_load = Signal(0)
        self.reg_b_inc = Signal()
        self.reg_b_dec = Signal()
        self.reg_b_out = Signal()

        self.mux_b_sel = Signal('zero')
        self.mux_b_out = Signal()

        self.alu_out = Signal()
        self.alu_sel = Signal('ADD')
        self.alu_c = Signal(False)
        self.alu_z = Signal(False)
        self.alu_n = Signal(False)

        self.ram_sel = Signal()
        self.ram_load = Signal()
        self.ram_in = Signal()
        self.ram_out = Signal()

        self.mux_s_out = Signal()
        self.mux_s_sel = Signal('lit')

        self.sp_out = Signal(-1)
        self.sp_load = Signal()
        self.sp_inc = Signal()
        self.sp_dec = Signal()

        self.adder_out = Signal()

        self.mux_data_in_out = Signal()
        self.mux_data_in_sel = Signal('alu')

        self.mux_pc_sel = Signal('lit')
        self.mux_pc_out = Signal()

        self.reg_z_out = Signal(False)
        self.reg_c_out = Signal(False)
        self.reg_n_out = Signal(False)

        self.instances['control_unit'] = ControlUnit(
            in_={
                'opcode': self.opcode,
                'c': self.reg_c_out,
                'z': self.reg_z_out,
                'n': self.reg_n_out
            },
            out={
                'reg_a_inc': self.reg_a_inc,
                'reg_a_dec': self.reg_a_dec,
                'reg_a_load': self.reg_a_load,
                'reg_b_inc': self.reg_b_inc,
                'reg_b_dec': self.reg_b_dec,
                'reg_b_load': self.reg_b_load,
                'mux_a_sel': self.mux_a_sel,
                'mux_b_sel': self.mux_b_sel,
                'alu_sel': self.alu_sel,
                'pc_load': self.pc_load,
                'mux_pc_sel': self.mux_pc_sel,
                'mux_s_sel': self.mux_s_sel,
                'sp_inc': self.sp_inc,
                'sp_dec': self.sp_dec,
                'mux_data_in_sel': self.mux_data_in_sel,
                'ram_load': self.ram_load
            }
        )

        self.instances['reg_c'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.alu_c,
                'load': Signal(1),
                'inc': Signal(0),
                'dec': Signal(0)
            },
            out={
                'data_out': self.reg_c_out
            }
        )

        self.instances['reg_z'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.alu_z,
                'load': Signal(1),
                'inc': Signal(0),
                'dec': Signal(0)
            },
            out={
                'data_out': self.reg_z_out
            }
        )

        self.instances['reg_n'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.alu_n,
                'load': Signal(1),
                'inc': Signal(0),
                'dec': Signal(0)
            },
            out={
                'data_out': self.reg_n_out
            }
        )

        self.instances['pc'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.mux_pc_out,
                'load': self.pc_load,
                'inc': Signal(1),
                'dec': self.pc_dec
            },
            out={
                'data_out': self.pc_out
            }
        )

        self.instances['rom'] = Rom(
            rom_path,
            in_={
                'pc': self.pc_out
            },
            out={
                'lit': self.lit,
                'opcode': self.opcode
            },
            head=head
        )

        self.instances['sp'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': Signal(),
                'load': self.sp_load,
                'inc': self.sp_inc,
                'dec': self.sp_dec
            },
            out={
                'data_out': self.sp_out
            }
        )

        self.instances['reg_a'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.alu_out,
                'load': self.reg_a_load,
                'inc': self.reg_a_inc,
                'dec': self.reg_a_dec
            },
            out={
                'data_out': self.reg_a_out
            }
        )

        self.instances['mux_a'] = Mux(
            in_={
                'one': Signal(1),
                'zero': Signal(0),
                'reg_a': self.reg_a_out,
                'sel': self.mux_a_sel,
            },
            out={
                'data_out': self.mux_a_out
            }
        )

        self.instances['reg_b'] = Reg(
            in_={
                'clock': self.clock,
                'data_in': self.alu_out,
                'load': self.reg_b_load,
                'inc': self.reg_b_inc,
                'dec': self.reg_b_dec
            },
            out={
                'data_out': self.reg_b_out
            }
        )

        self.instances['mux_b'] = Mux(
            in_={
                'zero': Signal(0),
                'one': Signal(1),
                'reg_b': self.reg_b_out,
                'lit': self.lit,
                'ram': self.ram_out,
                'sel': self.mux_b_sel,
            },
            out={
                'data_out': self.mux_b_out
            }
        )

        self.instances['alu'] = Alu(
            in_={
                'a': self.mux_a_out,
                'b': self.mux_b_out,
                'sel': self.alu_sel
            },
            out={
                'c': self.alu_c,
                'z': self.alu_z,
                'n': self.alu_n,
                'data_out': self.alu_out
            }
        )

        self.instances['mux_s'] = Mux(
            in_={
                'sp': self.sp_out,
                'lit': self.lit,
                'reg_b': self.reg_b_out,
                'sel': self.mux_s_sel,
            },
            out={
                'data_out': self.mux_s_out,
            }
        )

        self.instances['mux_data_in'] = Mux(
            in_={
                'alu': self.alu_out,
                'adder': self.adder_out,
                'sel': self.mux_data_in_sel,
            },
            out={
                'data_out': self.mux_data_in_out,
            }
        )

        self.instances['ram'] = Ram(
            in_={
                'clock': self.clock,
                'data_in': self.mux_data_in_out,
                'sel': self.mux_s_out,
                'load': self.ram_load
            },
            out={
                'data_out': self.ram_out
            }
        )

        self.instances['adder'] = Adder(
            in_={
                'data_in': self.pc_out
            },
            out={
                'data_out': self.adder_out
            }
        )

        self.instances['mux_pc'] = Mux(
            in_={
                'ram': self.ram_out,
                'lit': self.lit,
                'sel': self.mux_pc_sel,
            },
            out={
                'data_out': self.mux_pc_out,
            }
        )

    def print_rom(self):
        print("ROM:")
        print('\n'.join(map(str, self.instances['rom'].instructions)))
        print("---")

    def behave(self):
        self.clock.value = (self.clock.value + 1) % 4   # 0 = 0, 1 = rising edge, 2 = 1, 3 = lower edge
        if self.clock.value == 1:
            if self.opcode.value == 'prt':
                if self.lit.value == 'a':
                    print(self.reg_a_out)
                elif self.lit.value == 'b':
                    print(self.reg_b_out)
                else:
                    print(str(hex(self.instances['ram'].data[self.lit.value]))[2:].upper())
        # print('-------')
        # print("STACK=", self.instances['ram'].data[-15:])
        # print("RAM=", self.instances['ram'].data)
        # print('OPCODE=', self.opcode)
        # print("CLOCK=", self.clock)
        # print('ALU=', self.alu_out)
        # print('C=', self.reg_c_out)
        # print('Z=', self.reg_z_out)
        # print('N=', self.reg_n_out)
        # print('REG A=', self.reg_a_out)
        # print('MUX A=', self.mux_a_sel, self.mux_a_out)
        # print('MUX B=', self.mux_b_sel, self.mux_b_out)
        # print('LIT=', self.lit)
        # print('RAM=', self.instances['ram'].data)
