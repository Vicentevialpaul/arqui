from .entity import Entity


class Adder(Entity):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def behave(self):
        self.data_out.value = self.data_in.value + 1
