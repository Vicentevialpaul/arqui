class Signal:

    def __init__(self, value=0):
        if isinstance(value, int):
            self.__value = value % (2**16)
        else:
            self.__value = value

    @property
    def value(self):
        return self.__value

    @value.setter
    def value(self, value):
        if isinstance(value, int):
            self.__value = value % (2**16)
        else:
            self.__value = value

    def __repr__(self):
        if isinstance(self.value, int):
            return str(hex(self.value))[2:].upper()
        else:
            return str(self.value)
