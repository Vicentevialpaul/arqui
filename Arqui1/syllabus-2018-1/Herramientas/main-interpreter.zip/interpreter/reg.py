from .entity import Entity


class Reg(Entity):

    def __init__(self, in_, out):
        super().__init__(in_, out)

    def behave(self):
        if self.clock.value == 1:
            if self.load.value == 1:
                self.data_out.value = self.data_in.value
            elif self.inc.value == 1:
                self.data_out.value += 1
            elif self.dec.value == 1:
                self.data_out.value -= 1
